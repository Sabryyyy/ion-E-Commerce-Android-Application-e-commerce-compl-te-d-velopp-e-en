package com.example.ecommerce.ui.adapter

class ProduitDiffCallback : DiffUtil.ItemCallback<Produit>() {
    override fun areItemsTheSame(oldItem: Produit, newItem: Produit): Boolean =
        oldItem.id == newItem.id

    override fun areContentsTheSame(oldItem: Produit, newItem: Produit): Boolean =
        oldItem == newItem
}