package com.example.ecommerce.ui.viewmodel

// ui/viewmodel/ProductViewModel.kt
class ProductViewModel(private val repository: ProductRepository) : ViewModel() {

    private val _produits = MutableStateFlow<List<Produit>>(emptyList())
    val produits: StateFlow<List<Produit>> = _produits.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    val panierItems: StateFlow<List<PanierItem>> = repository.panierItems
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val panierCount: StateFlow<Int> = repository.panierCount
        .stateIn(viewModelScope, SharingStarted.Lazily, 0)

    val favorisItems: StateFlow<List<FavoriItem>> = repository.favorisItems
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    init { chargerProduits() }

    fun chargerProduits() {
        viewModelScope.launch {
            _loading.value = true
            try {
                _produits.value = repository.getProduits()
            } catch (e: Exception) {
                // Gérer l'erreur
            } finally {
                _loading.value = false
            }
        }
    }

    fun ajouterAuPanier(produit: Produit, quantite: Int = 1) {
        viewModelScope.launch {
            repository.ajouterAuPanier(PanierItem(produitId = produit.id, nom = produit.nom,
                prix = produit.prix, quantite = quantite, imageUrl = produit.imageUrl))
        }
    }

    fun retirerDuPanier(item: PanierItem) {
        viewModelScope.launch { repository.retirerDuPanier(item) }
    }

    fun toggleFavori(produit: Produit) {
        viewModelScope.launch {
            repository.toggleFavori(FavoriItem(produitId = produit.id, nom = produit.nom,
                prix = produit.prix, imageUrl = produit.imageUrl))
        }
    }
}

// Factory pour instancier le ViewModel avec dépendances
class ProductViewModelFactory(private val repository: ProductRepository) :
    ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return ProductViewModel(repository) as T
    }
}