package com.example.ecommerce.ui.adapter

// ui/adapter/ProduitAdapter.kt
class ProduitAdapter(
    private val onAjouterPanier: (Produit) -> Unit,
    private val onToggleFavori: (Produit) -> Unit,
    private val onProduitClick: (Produit) -> Unit
) : ListAdapter<Produit, ProduitAdapter.ProduitViewHolder>(ProduitDiffCallback()) {

    private val favorisIds = mutableSetOf<Int>()

    fun setFavoris(ids: Set<Int>) {
        favorisIds.clear()
        favorisIds.addAll(ids)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProduitViewHolder {
        val binding = ItemProduitBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ProduitViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProduitViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ProduitViewHolder(private val binding: ItemProduitBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(produit: Produit) {
            binding.tvNom.text = produit.nom
            binding.tvPrix.text = String.format("%.2f TND", produit.prix)

            // Charger l'image avec Glide (ajouter dépendance dans build.gradle)
            Glide.with(binding.root)
                .load(produit.imageUrl)
                .placeholder(R.drawable.ic_placeholder)
                .into(binding.imgProduit)

            // Icône favori selon l'état
            val favIcon = if (favorisIds.contains(produit.id))
                R.drawable.ic_favorite else R.drawable.ic_favorite_border
            binding.btnFavori.setImageResource(favIcon)

            binding.root.setOnClickListener { onProduitClick(produit) }
            binding.btnAjouterPanier.setOnClickListener { onAjouterPanier(produit) }
            binding.btnFavori.setOnClickListener { onToggleFavori(produit) }
        }
    }
}