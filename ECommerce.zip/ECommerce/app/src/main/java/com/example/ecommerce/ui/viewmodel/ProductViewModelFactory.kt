package com.example.ecommerce.ui.viewmodel

class ProductViewModelFactory {
}