package com.example.ecommerce.data.local

interface ProduitDao {
}