@Dao
interface FavorisDao {
    @Query("SELECT * FROM favoris")
    fun getAll(): Flow<List<FavoriItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: FavoriItem)

    @Query("DELETE FROM favoris WHERE produitId = :id")
    suspend fun deleteById(id: Int)

    @Query("SELECT EXISTS(SELECT 1 FROM favoris WHERE produitId = :id)")
    fun isFavori(id: Int): Flow<Boolean>
}