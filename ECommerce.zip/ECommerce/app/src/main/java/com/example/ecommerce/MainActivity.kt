package com.example.ecommerce

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

// Dans MainActivity.kt — Badge de notification mis à jour dynamiquement
class MainActivity : AppCompatActivity() {

    private val viewModel: ProductViewModel by viewModels {
        ProductViewModelFactory((application as MyApp).repository)
    }
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupNavigation()
        observerBadgePanier()
    }

    private fun setupNavigation() {
        val navController = (supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment)
            .navController
        binding.bottomNavigation.setupWithNavController(navController)
    }

    private fun observerBadgePanier() {
        // Observer le StateFlow du nombre d'articles dans le panier
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.panierCount.collect { count ->
                    val badge = binding.bottomNavigation
                        .getOrCreateBadge(R.id.panierFragment)
                    if (count > 0) {
                        badge.isVisible = true
                        badge.number = count
                    } else {
                        badge.isVisible = false
                    }
                }
            }
        }
    }
}