package com.example.ecommerce.data.local

// data/local/AppDatabase.kt
@Database(
    entities = [ProduitEntity::class, PanierItem::class, FavoriItem::class],
    version = 2,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun panierDao(): PanierDao
    abstract fun favorisDao(): FavorisDao
    abstract fun produitDao(): ProduitDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ecommerce_db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                INSTANCE = instance
                instance
            }
        }

        // Migration version 1 → 2
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    "ALTER TABLE panier_items ADD COLUMN dateAjout INTEGER NOT NULL DEFAULT 0"
                )
            }
        }
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Création d'une nouvelle table commandes
                database.execSQL("""
            CREATE TABLE IF NOT EXISTS commandes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date INTEGER NOT NULL,
                total REAL NOT NULL,
                statut TEXT NOT NULL DEFAULT 'EN_COURS'
            )
        """)
            }
        }

// Enregistrement des migrations
        Room.databaseBuilder(context, AppDatabase::class.java, "ecommerce_db")
        .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
        .build()
    }
}