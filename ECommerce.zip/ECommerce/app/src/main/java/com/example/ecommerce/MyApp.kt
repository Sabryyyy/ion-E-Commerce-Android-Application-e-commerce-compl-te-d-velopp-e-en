package com.example.ecommerce

class MyApp {
}