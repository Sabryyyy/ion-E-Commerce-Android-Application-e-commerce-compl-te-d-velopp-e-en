package com.example.ecommerce.ui.fragment

class DetailFragment {
}