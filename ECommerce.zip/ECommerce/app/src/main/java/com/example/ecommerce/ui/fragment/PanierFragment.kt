package com.example.ecommerce.ui.fragment

// ui/fragment/PanierFragment.kt
class PanierFragment : Fragment(R.layout.fragment_panier) {

    private val viewModel: ProductViewModel by activityViewModels {
        ProductViewModelFactory((requireActivity().application as MyApp).repository)
    }
    private var _binding: FragmentPanierBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentPanierBinding.bind(view)

        val adapter = PanierAdapter { item -> viewModel.retirerDuPanier(item) }
        binding.recyclerViewPanier.adapter = adapter

        viewLifecycleOwner.lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.panierItems.collect { items ->
                    adapter.submitList(items)

                    // Calcul du total en temps réel
                    val total = items.sumOf { it.prix * it.quantite }
                    binding.tvTotal.text = String.format("Total : %.2f TND", total)
                    binding.layoutVide.isVisible = items.isEmpty()
                    binding.layoutContenu.isVisible = items.isNotEmpty()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}