package com.example.ecommerce

// data/local/SessionManager.kt
class SessionManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFS_NAME, Context.MODE_PRIVATE
    )

    companion object {
        private const val PREFS_NAME = "ecommerce_session"
        private const val KEY_TOKEN = "auth_token"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USER_NOM = "user_nom"
        private const val KEY_IS_LOGGED = "is_logged_in"
    }

    // Sauvegarder le token d'authentification
    fun sauvegarderSession(token: String, userId: Int, nom: String) {
        prefs.edit()
            .putString(KEY_TOKEN, token)
            .putInt(KEY_USER_ID, userId)
            .putString(KEY_USER_NOM, nom)
            .putBoolean(KEY_IS_LOGGED, true)
            .apply()
    }

    fun getToken(): String? = prefs.getString(KEY_TOKEN, null)

    fun getUserId(): Int = prefs.getInt(KEY_USER_ID, -1)

    fun getNomUtilisateur(): String? = prefs.getString(KEY_USER_NOM, null)

    fun isConnecte(): Boolean = prefs.getBoolean(KEY_IS_LOGGED, false)

    // Déconnexion : effacer toutes les données de session
    fun deconnecter() {
        prefs.edit().clear().apply()
    }
}

// Utilisation dans MainActivity
class MainActivity : AppCompatActivity() {
    private lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sessionManager = SessionManager(this)

        // Rediriger vers Login si non connecté
        if (!sessionManager.isConnecte()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
    }
}

// Ajout du token dans les headers Retrofit (Interceptor)
class AuthInterceptor(private val sessionManager: SessionManager) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request().newBuilder()
            .addHeader("Authorization", "Bearer ${sessionManager.getToken()}")
            .build()
        return chain.proceed(request)
    }
}