package com.example.ecommerce.data.model

// data/model/Produit.kt
data class Produit(
    val id: Int,
    val nom: String,
    val prix: Double,
    val imageUrl: String,
    val description: String,
    val categorie: String
)