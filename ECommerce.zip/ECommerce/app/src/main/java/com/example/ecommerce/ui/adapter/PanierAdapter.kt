package com.example.ecommerce.ui.adapter

class PanierAdapter {
}