// data/local/PanierDao.kt — avec transaction
@Dao
interface PanierDao {
    @Transaction
    @Query("SELECT * FROM panier_items")
    fun getAll(): Flow<List<PanierItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: PanierItem)

    @Delete
    suspend fun delete(item: PanierItem)

    @Query("DELETE FROM panier_items")
    suspend fun viderPanier()

    @Query("UPDATE panier_items SET quantite = :quantite WHERE id = :id")
    suspend fun updateQuantite(id: Int, quantite: Int)

    @Query("SELECT COUNT(*) FROM panier_items")
    fun getCount(): Flow<Int>
}

// Opération transactionnelle dans le Repository
class ProductRepository(...) {

    // Transaction atomique : vider le panier après commande
    suspend fun passerCommande(): Boolean {
        return try {
            db.withTransaction {
                // Vérifier le stock, créer la commande, vider le panier
                // Si une étape échoue → tout est annulé (rollback automatique)
                val items = panierDao.getAll().first()
                if (items.isEmpty()) return@withTransaction false
                // ... logique commande ...
                panierDao.viderPanier()
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}