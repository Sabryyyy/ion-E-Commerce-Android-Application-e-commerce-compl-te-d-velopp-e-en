package com.example.ecommerce.data.local.entities

@Entity(
    tableName = "panier_items",
    foreignKeys = [ForeignKey(
        entity = ProduitEntity::class,
        parentColumns = ["id"],
        childColumns = ["produitId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("produitId")]
)
data class PanierItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val produitId: Int,
    val nom: String,
    val prix: Double,
    val quantite: Int,
    val imageUrl: String
)