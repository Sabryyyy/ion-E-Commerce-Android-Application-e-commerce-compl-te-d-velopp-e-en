package com.example.ecommerce.ui.fragment

// ui/fragment/CatalogueFragment.kt
class CatalogueFragment : Fragment(R.layout.fragment_catalogue) {

    private val viewModel: ProductViewModel by activityViewModels {
        ProductViewModelFactory((requireActivity().application as MyApp).repository)
    }
    private lateinit var adapter: ProduitAdapter
    private var _binding: FragmentCatalogueBinding? = null
    private val binding get() = _binding!!

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        _binding = FragmentCatalogueBinding.bind(view)

        setupRecyclerView()
        observeData()
    }

    private fun setupRecyclerView() {
        adapter = ProduitAdapter(
            onAjouterPanier = { produit ->
                viewModel.ajouterAuPanier(produit)
                Snackbar.make(binding.root, "${produit.nom} ajouté au panier", Snackbar.LENGTH_SHORT).show()
            },
            onToggleFavori = { viewModel.toggleFavori(it) },
            onProduitClick = { produit ->
                val action = CatalogueFragmentDirections
                    .actionCatalogueToDetail(produit.id)
                findNavController().navigate(action)
            }
        )

        binding.recyclerView.apply {
            layoutManager = GridLayoutManager(requireContext(), 2)
            adapter = this@CatalogueFragment.adapter
            setHasFixedSize(true)
        }
    }

    private fun observeData() {
        viewLifecycleOwner.lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.produits.collect { produits ->
                        adapter.submitList(produits)
                    }
                }
                launch {
                    viewModel.favorisItems.collect { favoris ->
                        adapter.setFavoris(favoris.map { it.produitId }.toSet())
                    }
                }
                launch {
                    viewModel.loading.collect { loading ->
                        binding.progressBar.isVisible = loading
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}