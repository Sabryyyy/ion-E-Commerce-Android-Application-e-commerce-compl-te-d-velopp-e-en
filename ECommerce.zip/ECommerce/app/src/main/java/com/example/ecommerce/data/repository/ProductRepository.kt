package com.example.ecommerce.data.repository

// data/repository/ProductRepository.kt
class ProductRepository(
    private val panierDao: PanierDao,
    private val favorisDao: FavorisDao,
    private val apiService: ProductApiService
) {
    val panierItems: Flow<List<PanierItem>> = panierDao.getAll()
    val favorisItems: Flow<List<FavoriItem>> = favorisDao.getAll()
    val panierCount: Flow<Int> = panierDao.getCount()

    suspend fun getProduits(): List<Produit> = apiService.getProduits()

    suspend fun ajouterAuPanier(item: PanierItem) = panierDao.insert(item)
    suspend fun retirerDuPanier(item: PanierItem) = panierDao.delete(item)

    suspend fun toggleFavori(item: FavoriItem) {
        val existe = favorisDao.isFavori(item.produitId).first()
        if (existe) favorisDao.deleteById(item.produitId)
        else favorisDao.insert(item)
    }
}