package com.example.ecommerce.data.local.entities

@Entity(
    tableName = "favoris",
    foreignKeys = [ForeignKey(
        entity = ProduitEntity::class,
        parentColumns = ["id"],
        childColumns = ["produitId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("produitId")]
)
data class FavoriItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val produitId: Int,
    val nom: String,
    val prix: Double,
    val imageUrl: String
)

data class ProduitAvecPanier(
    @Embedded val produit: ProduitEntity,
    @Relation(
        parentColumn = "id",
        entityColumn = "produitId"
    )
    val panierItems: List<PanierItem>
)