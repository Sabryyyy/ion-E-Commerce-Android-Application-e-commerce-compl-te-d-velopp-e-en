package com.example.ecommerce.data.local.entities


@Entity(tableName = "produits")
data class ProduitEntity(
    @PrimaryKey val id: Int,
    val nom: String,
    val prix: Double,
    val imageUrl: String,
    val description: String,
    val categorie: String
)
