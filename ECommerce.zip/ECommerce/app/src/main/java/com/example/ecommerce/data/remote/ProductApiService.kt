package com.example.ecommerce.data.remote

interface ProductApiService {
}